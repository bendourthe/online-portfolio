# Trivia Quiz example: start here

This bundle has two folders:

- trivia-quiz: the app you work on. Open index.html in a browser to play it.
- quiz-shuffle-reference: a small reference used by the compare step. Keep it next to the app.

## Setup

    cd trivia-quiz
    git init
    git add -A
    git commit -m "chore: seed Trivia Quiz"
    npm install

(npm install is only needed for the test step, which uses Vitest.)

Then follow the training, copying each prompt as you go. The compare step uses the path ../quiz-shuffle-reference.
